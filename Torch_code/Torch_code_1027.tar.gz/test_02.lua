type_list = {'chal600', 'mimic600', 'chal300+mimic300', 'chal600+mimic600', 'chal600+mimic1200', 'chal600+mimic2400', 'chal600+mimicAll'}

require 'experiment_02'
experiment_02('', 'chal600+mimicAll')
-- for i = 1, 7 do
  -- experiment_02('03_data', 'test_idea')
-- end
